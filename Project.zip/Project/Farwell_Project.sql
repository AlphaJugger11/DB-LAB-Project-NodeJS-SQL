create database if not exists farewell;
use farewell;

CREATE TABLE if not exists Students (
    UserId varchar(4) PRIMARY KEY,
    Name VARCHAR(255),
    Email VARCHAR(255) CHECK (Email LIKE '%@nu.edu.pk'),
    Password VARCHAR(255) CHECK (LENGTH(Password) >= 8),
    PersonalDetails TEXT,
    DietaryPreferences TEXT,
    NumberOfAdditionalMembers INT
);
INSERT INTO Students (UserId, Name, Email, Password, PersonalDetails, DietaryPreferences, NumberOfAdditionalMembers) VALUES
('S1', 'Muhammad Ali', 'muhammad.ali@nu.edu.pk', 'password123', 'DOB: 01/01/1990, Address: Lahore, Pakistan', 'Biryani, Nihari, Seekh Kabab', 2),
('S2', 'Fatima Khan', 'fatima.khan@nu.edu.pk', 'securepass', 'DOB: 05/10/1995, Address: Karachi, Pakistan', 'Pulao, Karahi, Chapli Kabab', 1),
('S3', 'Ahmed Hussain', 'ahmed.hussain@nu.edu.pk', 'strongpass', 'DOB: 12/15/1988, Address: Islamabad, Pakistan', 'Samosa, Haleem, Paye', 0),
('S4', 'Ayesha Malik', 'ayesha.malik@nu.edu.pk', 'mysecurepassword', 'DOB: 08/20/1992, Address: Rawalpindi, Pakistan', 'Biryani, Chapati, Sindhi Biryani', 3),
('S5', 'Usman Khan', 'usman.khan@nu.edu.pk', 'password1234', 'DOB: 03/25/1994, Address: Lahore, Pakistan', 'Pulao, Nihari, Sheer Khurma', 1);

                 -- password / id got from input
SELECT *
FROM Students
WHERE UserID = 'S1' AND Password = 'passw';

CREATE TABLE if not exists Teachers (
    Id varchar(4) PRIMARY KEY,
    Name VARCHAR(255),
    Password VARCHAR(255) CHECK (LENGTH(Password) >= 8)
);
INSERT INTO Teachers (Id, Name, Password) VALUES
('T1', 'Dr. Ali Khan', 'strongpassword'),
('T2', 'Prof. Fatima Ahmed', 'securepass123'),
('T3', 'Ms. Ayesha Malik', 'mypassword'),	
('T4', 'Mr. Omar Khan', 'verysecurepassword');

CREATE TABLE if not exists AccompanyingMembers (
    UserId VARCHAR(10),
    TeacherId varchar(4),
    Name VARCHAR(255),
    Relationship VARCHAR(50),
    PRIMARY KEY (UserId, TeacherId),
    FOREIGN KEY (TeacherId) REFERENCES Teachers(Id)
);
INSERT INTO AccompanyingMembers (UserId, TeacherId, Name, Relationship) VALUES
('U1', 'T1', 'Amina Khan', 'Child'),
('U2','T1', 'Kashif' , 'Child'),
('U2', 'T2', 'Ali Ahmed', 'Child'),
('U3', 'T3', 'Sara Malik', 'Wife');


SELECT *
FROM AccompanyingMembers
WHERE TeacherId = 'T1';

CREATE TABLE if not exists AccompanyingMembersofStudents (
    UserId VARCHAR(10),
    StudentId varchar(4),
    Name VARCHAR(255),
    Relationship VARCHAR(50),
    PRIMARY KEY (UserId, StudentId),
    FOREIGN KEY (StudentId) REFERENCES Students(UserId)
);
INSERT INTO AccompanyingMembersofStudents (UserId, StudentId, Name, Relationship) VALUES
('U1', 'S1', 'Amina Khan', 'Parent'),
('U2', 'S2', 'Ali Ahmed', 'Sibling'),
('U2', 'S3', 'Sara Malik', 'Sibling');

SELECT *
FROM AccompanyingMembersofStudents
WHERE StudentId = 'S1';

CREATE TABLE if not exists Menu (
    FoodId varchar(4) PRIMARY KEY,
    FoodName VARCHAR(255),
    TotalVotes INT
);
INSERT INTO Menu (FoodId, FoodName, TotalVotes) VALUES
('F1', 'Chicken Biryani', 25),
('F2', 'Vegetable Pulao', 18),
('F3', 'Beef Karahi', 20);

CREATE TABLE if not exists VotedForMenu (
    MenuId varchar(4),
    StudentId varchar(4),
    PRIMARY KEY (MenuId, StudentId),
    FOREIGN KEY (MenuId) REFERENCES Menu(FoodId),
    FOREIGN KEY (StudentId) REFERENCES Students(UserId)
);

-- Direcly increments votes MENUS
-- const query = 'INSERT INTO VotedForMenu (MenuId, StudentId) VALUES (?, ?)';

-- // Execute the query with the values passed as an array
-- connection.query(query, [menuId, studentId], (error, results, fields) => {
--   if (error) {
--     console.error('Error inserting into VotedForMenu table:', error);
--     return;
--   }

--  SQL
	
INSERT INTO VotedForMenu (MenuId, StudentId) VALUES		
('F1','S1'),
('F2','S1'),
('F1','S2');

--   SUGGEST MENUS by student does this --
Insert into menu (foodId,foodname) values('F5','bilyaani');
-- node js
-- const query = 'INSERT INTO Menu (FoodId, FoodName) VALUES (?, ?)';

CREATE TABLE if not exists Performances (
    PerformanceId VARCHAR(10) PRIMARY KEY,
    Title VARCHAR(255),
    Type VARCHAR(50),
    Duration TIME,
    Requirements TEXT,
    Votes int default(0),
    Venue varchar(5),
    Status varchar (10),
    TimeSlots timestamp
);
INSERT INTO Performances (PerformanceId, Title, Type, Duration, Requirements) VALUES
('P1', 'The Great Play', 'Drama', '02:30:00', 'Stage, lighting equipment, props'),
('P2', 'Magical Music', 'Musical', '01:45:00', 'Music instruments, stage'),
('P3', 'Comedy Show', 'Comedy', '01:15:00', 'Microphones, stage, props');

-- node js
--  const query = 'INSERT INTO Performances (PerformanceId, Title, Type, Duration, Requirements) VALUES (?, ?, ?, ?, ?)';


CREATE TABLE if not exists VotedForPerformances (
    PerformanceId VARCHAR(10),
    StudentId VARCHAR(10),
    PRIMARY KEY (PerformanceId, StudentId),
    FOREIGN KEY (PerformanceId) REFERENCES Performances(PerformanceId),
    FOREIGN KEY (StudentId) REFERENCES Students(UserId)
);
INSERT INTO VotedForPerformances (PerformanceId, StudentId) VALUES
('P3', 'S3');
 
-- for node js 
--  --  const query = 'INSERT INTO VotedForPerformances (PerformanceId, StudentId) VALUES (?, ?)';

CREATE TABLE if not exists Categories (
    CategoryId VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(255),
    Budget DECIMAL(10, 2) DEFAULT 0
);
-- Organiser would get values from here 

INSERT INTO Categories (CategoryId, Name) VALUES
('c1', 'Decorations'),
('c2', 'Venue Setup'),
('c3', 'Dinner Menu'),
('c4', 'Performances'),
('c5', 'Make Invitations');

-- MANAGERS  
CREATE TABLE if not exists Managers (
    ManagerId VARCHAR(10) PRIMARY KEY,
    Name VARCHAR(255),
    Password VARCHAR(255) CHECK (LENGTH(Password) >= 8),
    Email VARCHAR(255),
    ManagesCategory VARCHAR(10),
    FOREIGN KEY (ManagesCategory) REFERENCES Categories(CategoryId),
    UNIQUE (ManagesCategory)
);
-- INSERT INTO Managers (ManagerId, Name, Password, Email, ManagesCategory) VALUES
-- ('M1', 'Ahmed Khan', 'password1', 'ahmed.khan@nu.edu.pk', 'c1'),
-- ('M2', 'Fatima Ali', 'password2', 'fatima.ali@nu.edu.pk', 'c2'),
-- ('M3', 'Sana Ahmed', 'password3', 'sana.ahmed@nu.edu.pk', 'c3'),
-- ('M4', 'Ali Hassan', 'password4', 'ali.hassan@nu.edu.pk', 'c4'),
-- ('M5', 'Ayesha Khan', 'password5', 'ayesha.khan@nu.edu.pk', 'c5');

CREATE TABLE if not exists Volunteer (
    StudentId VARCHAR(10),
    CategoryId VARCHAR(10),
    PRIMARY KEY (StudentId, CategoryId),
    FOREIGN KEY (StudentId) REFERENCES Students(UserId),
    FOREIGN KEY (CategoryId) REFERENCES Categories(CategoryId)
);
-- Insert values into Volunteer table
INSERT INTO Volunteer (StudentId, CategoryId) VALUES
('S1', 'c1'),  -- Ahmed Khan volunteers for Decorations
('S2', 'c2'),  -- Fatima Ali volunteers for Venue Setup
('S3', 'c2'),  -- Sana Ahmed volunteers for Dinner Menu
('S4', 'c4'),  -- Ali Hassan volunteers for Performances
('S5', 'c1');  -- Ayesha Khan volunteers for Make Invitations

 -- Getting volunteer details on basis of manager id --
SELECT v.StudentId, v.CategoryId, c.Name AS CategoryName      -- to get volunteer details
FROM Volunteer v
JOIN Categories c ON v.CategoryId = c.CategoryId
JOIN Managers m ON c.CategoryId = m.ManagesCategory
WHERE m.ManagerId = 'M2';

SELECT v.StudentId , v.CategoryId		-- when manager logins heres' how he would see all the volunteers of his category
FROM Volunteer v 
JOIN Managers m ON m.ManagesCategory = v.CategoryID
WHERE v.StudentId = 'S2';				-- M2 will be replaced by the manager who logged in

CREATE TABLE if not exists Tasks (
    TaskId int PRIMARY KEY auto_increment,
    ManagerId VARCHAR(10),
    StudentId VARCHAR(10),
    Deadline DATE,
    TaskDescription TEXT,
    FOREIGN KEY (ManagerId) REFERENCES Managers(ManagerId),
    FOREIGN KEY (StudentId) REFERENCES Students(UserId)
);
--  Now when managers opens dashboard , from above query he will only see volunteers for his category
--  Ab if he presses/ selects Student 1 , he would add these things, description, time etc

INSERT INTO Tasks ( ManagerId, StudentId, Deadline, TaskDescription) VALUES
( 'M1', 'S1', '2024-05-20', 'Decorate the hall'),
('M2', 'S2', '2024-05-22', 'Set up sound system'),
('M3', 'S3', '2024-05-25', 'Prepare menu');

SELECT TaskId, TaskDescription, Deadline FROM TASKS t
WHERE t.StudentId = 'S2';	-- when logged in student click task, this query would run


--   budget allocated to each manager -- 
SELECT c.Budget
FROM Categories c
JOIN Managers m ON c.CategoryId = m.ManagesCategory
WHERE m.ManagerId = 'M2';

UPDATE Categories
SET Budget = 5000
WHERE CategoryId = 'c1';























