const express = require("express");
var mysql = require("mysql");
const app = express();
const path = require("path");
var connection = mysql.createConnection({             
    host: "localhost",
    user: "",
    password: "",
    database: "farewell"
});
const fs = require('fs');
const port = 8080;
var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: true }));
app.listen(port, function(){                       
    console.log(`Listening on port ${port}...`);  
});
connection.connect(function(err) {
    if (err) {
        return console.error('error: ' + err.message);
    }
    console.log('Connected to the MySQL server.');
});
// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'Main')));
app.get("/", function(req, res) {
    res.sendFile(path.join(__dirname, "Main", "index.html"));
});
global.globalUserID = '';
app.post("/registerT", function(req, res) {
    var id = req.body.rollNumber;
    var name = req.body.name;
    var password = req.body.password;
    var checkbox = req.body.checkbox;
    if (checkbox == "on") {
        var numFamilyMembers = req.body.numFamilyMembers;
        if (numFamilyMembers == 1){
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var sql_teacher = "INSERT INTO Teachers (Id, Name, Password) VALUES (?, ?, ?)";
            var sql_family = "INSERT INTO AccompanyingMembers (TeacherId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_teacher, [id, name, password], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
        else if(numFamilyMembers == 2){
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var familyMemberName2 = req.body.familyMemberName2;
            var relation2 = req.body.relation2;
            var sql_teacher = "INSERT INTO Teachers (Id, Name, Password) VALUES (?, ?, ?)";
            var sql_family = "INSERT INTO AccompanyingMembers (TeacherId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_teacher, [id, name, password], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName2, relation2], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
        else{
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var familyMemberName2 = req.body.familyMemberName2;
            var relation2 = req.body.relation2;
            var familyMemberName3 = req.body.familyMemberName3;
            var relation3 = req.body.relation3;
            var sql_teacher = "INSERT INTO Teachers (Id, Name, Password) VALUES (?, ?, ?)";
            var sql_family = "INSERT INTO AccompanyingMembers (UserId,TeacherId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_teacher, [id,id, name, password], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName2, relation2], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [id, familyMemberName3, relation3], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
    } else {
        var sql = "INSERT INTO Teachers (Id, Name, Password) VALUES (?, ?, ?)";
        connection.query(sql, [id, name, password], function(err, result) {
            if (err) throw err;
            console.log("1 record inserted");
        }
        );
    }
    res.status(200).send("Teacher Registered");
});
function generateRandomId(){
    var randomIds = [];
    for (var i = 0; i < 4; i++) {
        var randomId = Math.floor(Math.random() * 1000);
        randomIds.push(randomId);
    }
    return randomIds;
}
app.post("/registerS", function(req, res) {
    // Handling registration of students
    var UserId = req.body.UserId;
    var name = req.body.name;
    var password = req.body.password;
    var Dietary = req.body.Dietary;
    var numFamilyMembers = req.body.numFamilyMembers;
    var email = req.body.email; // Extract email from request body
    var checkbox = req.body.checkbox;
    if(checkbox == "on"){
        if (numFamilyMembers == 1){
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var sql_student = "INSERT INTO Students (UserId, Name, Password, DietaryPreferences, Email) VALUES (?, ?, ?, ?, ?)";
            var sql_family = "INSERT INTO accompanyingmembersofstudents (UserId,StudentId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_student, [UserId, name, password, Dietary, email], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [1,UserId, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
        else if(numFamilyMembers == 2){
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var familyMemberName2 = req.body.familyMemberName2;
            var relation2 = req.body.relation2;
            var sql_student = "INSERT INTO Students (UserId, Name, Password, DietaryPreferences, Email) VALUES (?, ?, ?, ?, ?)";
            var sql_family = "INSERT INTO accompanyingmembersofstudents (UserId,StudentId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_student, [UserId, name, password, Dietary, email], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [2,UserId, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [3,UserId, familyMemberName2, relation2], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
        else{
            var familyMemberName1 = req.body.familyMemberName1;
            var relation1 = req.body.relation1;
            var familyMemberName2 = req.body.familyMemberName2;
            var relation2 = req.body.relation2;
            var familyMemberName3 = req.body.familyMemberName3;
            var relation3 = req.body.relation3;
            var sql_student = "INSERT INTO Students (UserId, Name, Password, DietaryPreferences, Email) VALUES (?, ?, ?, ?, ?)";
            var sql_family = "INSERT INTO accompanyingmembersofstudents (UserId,StudentId, Name, Relationship) VALUES (?, ?, ?)";
            connection.query(sql_student, [UserId, name, password, Dietary, email], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [1,UserId, familyMemberName1, relation1], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [2,UserId, familyMemberName2, relation2], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
            connection.query(sql_family, [3,UserId, familyMemberName3, relation3], function(err, result) {
                if (err) throw err;
                console.log("1 record inserted");
            }
            );
        }
    }
    else{
        var sql = "INSERT INTO Students (UserId, Name, Password, DietaryPreferences, Email) VALUES (?, ?, ?, ?, ?)";
        connection.query(sql, [UserId, name, password, Dietary, email], function(err, result) {
            if (err) throw err;
            console.log("1 record inserted");
        }
        );
    }
    res.status(200).send("Student Registered");
}
);
app.get('/getUsernameS', function(req, res) {
    var sql = "SELECT Name FROM Students WHERE UserId = ?";
    connection.query(sql, [globalUserID], function(err, result) {
        if (err) throw err;
        res.json({ username: result[0].Name });
    });
  });
  app.get('/getUsernameM', function(req, res) {
    var sql = "SELECT Name FROM Managers WHERE ManagerID = ?";
    connection.query(sql, [globalUserID], function(err, result) {
        if (err) throw err;
        res.json({ username: result[0].Name });
    });
  });
app.post("/loginS", function(req, res) {
    var userId = req.body.userId;
    var password = req.body.password;
    var sql = "SELECT * FROM Students WHERE UserId = ? AND Password = ?";
    connection.query(sql, [userId, password], function(err, result) {
        if (err) throw err;
        if (result.length > 0) {
            globalUserID = userId;
            res.redirect("/studentdb.html");
        } else {
            res.status(404).send("Student not found");
        }
    });
}); 
app.get("")
app.post("/loginT", function(req, res) {
    var userId = req.body.userId;
    var password = req.body.password;
    var sql = "SELECT * FROM Teachers WHERE Id = ? AND Password = ?";
    connection.query(sql, [userId, password], function(err, result) {
        if (err) throw err;
        if (result.length > 0) {
            globalUserID = userId;
            res.status(200).send("Teacher Logged In");
        }
        else {
            res.status(404).send("Teacher not found");
        }
    }
    );
}
);
app.get('/getVolunteers', function(req, res) {
    var managerId = globalUserID; // Get the logged-in manager's ID from the session
    // retrieve the category of the manager
    var sql = "SELECT ManagesCategory FROM Managers WHERE ManagerId = ?";
    connection.query(sql, [managerId], function(err, result) {
        if (err) {
            console.error(err);
            res.status(500).send("Server error");
            return;
        }
        var category = result[0].ManagesCategory;
        // Get the volunteers for the manager's category
        var sql = `
            SELECT Students.Name, Tasks.TaskDescription
            FROM Volunteer
            INNER JOIN Students ON Volunteer.StudentID = Students.UserID
            INNER JOIN Tasks ON Volunteer.StudentID = Tasks.StudentID
            WHERE Tasks.ManagerID = ?
        `;
        connection.query(sql, [managerId], function(err, result) {
            if (err) {
                console.error(err);
                res.status(500).send("Server error");
                return;
            }
            var volunteers = result.map(function(row) {
                return { name: row.Name, task: row.TaskDescription, deadline: row.Deadline };
            });
            console.log(volunteers);
            res.json({ volunteers: volunteers });
        });
    });
});
app.post("/loginO", function(req, res) {
    var userId = req.body.userId;
    var password = req.body.password;
    var sql = "SELECT * FROM Managers WHERE ManagerId = ? AND Password = ?";
    var sql2 = "SELECT ManagesCategory FROM Managers WHERE ManagerId = ? AND Password = ?";
    connection.query(sql, [userId, password], function(err, result) {
        if (err) throw err;
        if (result.length > 0) {
            connection.query(sql2, [userId], function(err, result) {
                if (err) throw err;
                if (result == "c5") {
                    globalUserID = userId;
                    res.redirect("/organizer.html");
                } else {
                    res.status(404).send("Organizer not found");
                }
            }
            );
        } else {
            res.status(404).send("Organizer not found");
        }
    }
    );
});

app.post("/loginM", function(req, res) {
    var userId = req.body.userId;
    var password = req.body.password;
    var sql = "SELECT * FROM Managers WHERE ManagerId = ? AND Password = ?";
    console.log(userId);
    connection.query(sql, [userId, password], function(err, result) {
        if (err) throw err;
        if (result.length > 0) {
            globalUserID = userId;
            res.redirect("/managerdb.html");
        } else {
            res.status(404).send("Manager not found");
        }
    }
    );
}
);


// Define a function to fetch category names from the database
function getCategoryNames(callback) {
    // Define the SQL query
    const sqlQuery = 'SELECT Name FROM Categories';

    // Execute the SQL query
    connection.query(sqlQuery, (error, results) => {
        if (error) {
            // Handle the error
            console.error('Error fetching category names:', error);
            callback(error, null);
        } else {
            // Extract category names from the results
            const categoryNames = results.map(result => result.Name);

            // Call the callback function with the category names array
            callback(null, categoryNames);
        }
    });
}