SELECT * FROM farewell.students;

Delimiter $
CREATE TRIGGER  UpdateVoteCount     --  trigger for vote count
AFTER INSERT ON VotedForMenu
FOR EACH ROW
BEGIN
    UPDATE Menu
    SET TotalVotes = TotalVotes + 1
    WHERE FoodId = NEW.MenuId;
    
End $
Delimiter ;

Delimiter @
CREATE TRIGGER UpdatePerformanceVoteCount
AFTER INSERT ON VotedForPerformances
FOR EACH ROW
BEGIN
    UPDATE Performances
    SET Votes = Votes + 1
    WHERE PerformanceId = NEW.PerformanceId;
END @
Delimiter ;
INSERT INTO VotedForMenu (MenuId, StudentId) VALUES ('F2', 'S2');
