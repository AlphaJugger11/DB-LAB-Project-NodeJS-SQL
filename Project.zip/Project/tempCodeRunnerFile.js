app.get('/getVolunteers', function(req, res) {
    var managerId = req.session.globalUserID; // Get the logged-in manager's ID from the session
    var sql = `
        SELECT Students.Name, Tasks.TaskDescription, Tasks.Deadline 
        FROM Volunteers 
        INNER JOIN Students ON Volunteers.StudentID = Students.StudentID
        INNER JOIN Tasks ON Volunteers.StudentID = Tasks.StudentID
        WHERE Tasks.ManagerID = ?
    `;
    connection.query(sql, [managerId], function(err, result) {
        if (err) {
            console.error(err);
            res.status(500).send("Server error");
            return;
        }
        var volunteers = result.map(function(row) {
            return { name: row.Name, task: row.TaskDescription, deadline: row.Deadline };
        });
        res.json({ volunteers: volunteers });
    });
});