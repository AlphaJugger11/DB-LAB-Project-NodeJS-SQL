const categories = ["Decorations","Venue Setup","Dinner Menu","Performances","Make Invitations"];

// export default categories;
module.exports = categories;