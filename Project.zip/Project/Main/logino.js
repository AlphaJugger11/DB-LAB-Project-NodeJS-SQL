document.getElementById('bckbutt').addEventListener('click', function () {
  window.location.href = 'index.html';
});

document.getElementById('submit').addEventListener('click', function (event) {
  event.preventDefault(); // Prevent the default form submission behavior

  // Get the input values
  var userId = document.getElementById('userId').value;
  var password = document.getElementById('password').value;

  // Your validation logic goes here
  var isValid = validateInput(userId, password);

  if (isValid) {
    // If input is valid, redirect to managerdb.html
    window.location.href = 'organizer.html';
  }
});

function validateInput(userId, password) {
  // Dummy validation, you can replace it with your own logic
  if (userId === 'admin' && password === 'pw') {
    return true;
  } else {
    alert('Invalid user ID or password');
    return false;
  }
}
