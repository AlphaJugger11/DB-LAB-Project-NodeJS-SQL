document.getElementById('bckbutt').addEventListener('click', function () {
    window.location.href = 'index.html';
  });
  
document.querySelector('form').addEventListener('submit', function(event) {
    // Check if the input fields are empty
    if (document.getElementById('userId').value.trim() === '' || document.getElementById('password').value.trim() === '') {
        // Prevent form submission if fields are empty
        event.preventDefault();
            alert('Please fill in both fields.');
    }
});