document.getElementById('submit').addEventListener('click',function(){
    document.location.href = 'https://youtu.be/xvFZjo5PgG0?feature=shared';
});

document.getElementById('bckbutt').addEventListener('click',function(){
    document.location.href = 'index.html';
});

document.getElementById('new-user').addEventListener('click', function(){
    // Remove the required attribute from the input fields
    document.getElementById('userId').removeAttribute('required');
    document.getElementById('password').removeAttribute('required');
    // Redirect to the registration page
    document.location.href = 'teacher.html';
});

// Function to add required attribute to fields when login button is clicked
document.querySelector('button[type="submit"]').addEventListener('click', function() {
    // Add the required attribute back to the input fields
    document.getElementById('userId').setAttribute('required', true);
    document.getElementById('password').setAttribute('required', true);
});

// Function to validate form before submission
document.querySelector('form').addEventListener('submit', function(event) {
    // Check if the input fields are empty
    if (document.getElementById('userId').value.trim() === '' || document.getElementById('password').value.trim() === '') {
        // Prevent form submission if fields are empty
        event.preventDefault();
        // alert('Please fill in both fields.');
    }
});

// document.getElementById('submit')