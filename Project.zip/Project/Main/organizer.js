// Function to go back to the previous page
document.getElementById('bckbutt').addEventListener('click', function() {
    window.location.href = 'logino.html';
});

// Function to show the volunteer management screen
function showManagers() {
    // Get the main content element
    var mainContent = document.getElementById('main-content');

    // Clear any existing content
    mainContent.innerHTML = '';

    // Create the volunteer management screen
    var volunteerScreen = document.createElement('div');
    volunteerScreen.classList.add('volunteer-screen', 'active');

    // Create elements for displaying volunteers and their tasks
    var volunteersTable = document.createElement('table');
    volunteersTable.innerHTML = `
        <thead>
            <tr>
                <th>Manager Name</th>
                <th>Department Name</th>
                <th>Budget</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody class="volunteers-list">
            <tr>
                <td contenteditable="true">Manager Name</td>
                <td contenteditable="true">Dept. Name</td>
                <td><button class="button" id="dateee" style="border-radius: 10px; background-color: #4b6783; color: white; padding: 5px 10px; border: none; cursor: pointer;">Allocate Budget<input type="number" min="0" class="task-deadline" oninput="validateInput(this)" /></button></td>
                <p id="errorMsg" style="color: black; display: none;">Please enter a positive number.</p>
                <td>
                    <button class="edit-button" onclick="deleteVolunteer(this)">Delete</button>
                </td>
            </tr>
            <tr>
                <td contenteditable="true">Manager Name</td>
                <td contenteditable="true">Dept. Name</td>
                <td><button class="button" id="dateee" style="border-radius: 10px; background-color: #4b6783; color: white; padding: 5px 10px; border: none; cursor: pointer;">Allocate Budget<input type="number" min='0' class="task-deadline" oninput="validateInput(this)" /></button></td>
                <p id="errorMsg" style="color: black; display: none;">Please enter a positive number.</p>
                <td>
                    <button class="edit-button" onclick="deleteVolunteer(this)">Delete</button>
                </td>
            </tr>
        </tbody>
    `;

    // Create button to add new volunteer row
    var addVolunteerButton = document.createElement('button');
    addVolunteerButton.textContent = 'Add Volunteer';
    addVolunteerButton.classList.add('add-volunteer-button');

    addVolunteerButton.addEventListener('click', function() {
        addNewVolunteerRow();
    });

    // Append elements to the volunteer management screen
    volunteerScreen.appendChild(volunteersTable);
    volunteerScreen.appendChild(addVolunteerButton);

    // Append the volunteer management screen to the main content
    mainContent.appendChild(volunteerScreen);
}

// Function to add a new row for a volunteer
function addNewVolunteerRow() {
    // Get the volunteers table body
    var volunteersList = document.querySelector('.volunteers-list');

    // Create a new row
    var newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td contenteditable="true">Manager Name</td>
        <td contenteditable="true">Dept. Name</td>
        <td>
        <button class="button" id="dateee" style="border-radius: 10px; background-color: #4b6783; color: white; padding: 5px 10px; border: none; cursor: pointer;">Allocate Budget<input type="number" min='0' class="task-deadline" oninput="validateInput(this)" /></button>
        <p id="errorMsg" style="color: black; display: none;">Please enter a positive number.</p>
        </td>
        <td>
            <button class="edit-button" onclick="deleteVolunteer(this)">Delete</button>
        </td>
    `;

    // Append the new row to the volunteers table
    volunteersList.appendChild(newRow);

    // Add event listener for date selection
    newRow.querySelector('#dateee').addEventListener('click', function() {
        // When the button is clicked, focus on the corresponding date input
        newRow.querySelector('.task-deadline').focus();
    });
}
// Validating Input
function validateInput(input) {
    // Get the value entered by the user
    var value = input.value;

    // Check if the value is less than 0
    if (value < 0) {
        // Display an error message and clear the input
        document.getElementById('errorMsg').style.display = 'block';
        input.value = '';
    } else {
        // Hide the error message
        document.getElementById('errorMsg').style.display = 'none';
    }
}
// Function to delete a volunteer
function deleteVolunteer(button) {
    // Prompt the user for confirmation
    var confirmation = confirm('Are you sure you want to delete this volunteer?');
    if (confirmation) {
        // Remove the volunteer row
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
}

function budgetset() {
    // Prompt the user to enter the initial budget
    var budgetInput = prompt("Please enter the initial budget:");

    // Convert the input value to a number
    var budgetValue = parseFloat(budgetInput);

    // Check if the input is a positive number
    if (!isNaN(budgetValue) && budgetValue > 0) {
        // Input is a positive number
        alert("Initial budget set successfully: " + budgetValue);

        // Update the budget display on the screen
        document.getElementById("budget-value").innerText = "Total budget is " + budgetValue;
    } else {
        // Input is not a positive number
        alert("Please enter a valid positive number for the initial budget.");
    }
}
window.onload = function() {
    fetch('/getUsername')
      .then(response => response.json())
      .then(data => {
        document.getElementById('username').textContent = data.username;
      });
};