document.getElementById('bckbutt').addEventListener('click',function(){
    document.location.href = 'logins.html'
});

document.getElementById('register').addEventListener('click',function(){
    document.location.href = 'registerstudent.html';
}) ;

document.getElementById('volunteerMenu').addEventListener('click',function(){
    document.location.href = 'volunteer.html';
});
window.onload = function() {
    fetch('/getUsernameS')
      .then(response => response.json())
      .then(data => {
        document.getElementById('username').textContent = data.username;
      });
  };