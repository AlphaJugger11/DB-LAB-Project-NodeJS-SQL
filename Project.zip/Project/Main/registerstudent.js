const categories = ["Decorations","Venue Setup","Dinner Menu","Performances","Make Invitations"];
document.getElementById('bckbutt').addEventListener('click', function () {
  document.location.href = 'studentdb.html';
});

// Get the div where you want to insert the data
var departmentsDiv = document.getElementById('departments');

// Clear any existing content
departmentsDiv.innerHTML = '';

// Retrieve categories array from the end of the HTML file


// Loop through the categories array and create elements to display it
categories.forEach(function (category) {
  // Create a checkbox element
  var checkbox = document.createElement('input');
  checkbox.type = 'checkbox';
  checkbox.name = 'department';
  checkbox.value = category;
  
  // Create a label element for the checkbox
  var label = document.createElement('label');
  label.textContent = category;
  label.htmlFor = checkbox.id = `dept-${category}`;

  // Append the checkbox and label to the departmentsDiv
  departmentsDiv.appendChild(checkbox);
  departmentsDiv.appendChild(label);
  departmentsDiv.appendChild(document.createElement('br')); // Add a line break after each checkbox
});

// Handle form submission
document.getElementById('registration-form').addEventListener('submit', function (event) {
  event.preventDefault(); // Prevent default form submission

  // Get all checked checkboxes
  var checkedCheckboxes = document.querySelectorAll('input[name="department"]:checked');

  // Extract the values of checked checkboxes
  var selectedDepartments = [];
  checkedCheckboxes.forEach(function (checkbox) {
    selectedDepartments.push(checkbox.value);
  });

  // Log the selected departments (you can send it to the backend here)
  console.log('Selected departments:', selectedDepartments);

});

