document.getElementById('bckbutt').addEventListener('click',function(){
    document.location.href = 'studentdb.html';
})