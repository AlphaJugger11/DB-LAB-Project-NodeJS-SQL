// Function to go back to the previous page
window.onload = function() {
    fetch('/getUsernameM')
      .then(response => response.json())
      .then(data => {
        document.getElementById('username').textContent = data.username;
      });
  };

document.getElementById('bckbutt').addEventListener('click', function() {
    window.location.href = 'loginm.html';
});
document.getElementById('manageVolunteersBtn').addEventListener('click', function() {
    // Fetch list of volunteers from server
    fetch('/getVolunteers')
        .then(response => response.json())
        .then(data => {
            // Show volunteers
            alert('Volunteers loaded');
            showVolunteers(data.volunteers);
        });
});
// Function to show the volunteer management screen
// Function to show the volunteer management screen
function showVolunteers(volunteers) {
    // Get the main content element
    var mainContent = document.getElementById('main-content');

    // Clear any existing content
    mainContent.innerHTML = '';

    // Create the volunteer management screen
    var volunteerScreen = document.createElement('div');
    volunteerScreen.classList.add('volunteer-screen', 'active');

    // Create elements for displaying volunteers and their tasks
    var volunteersTable = document.createElement('table');
    volunteersTable.innerHTML = `
        <thead>
            <tr>
                <th>Volunteer Name</th>
                <th>Task</th>
                <th>Task Deadline</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody class="volunteers-list">
        </tbody>
    `;

    // Append the volunteers table to the volunteer management screen
    volunteerScreen.appendChild(volunteersTable);

    // Append the volunteer management screen to the main content
    mainContent.appendChild(volunteerScreen);

    // Add each volunteer to the table
    for (var i = 0; i < volunteers.length; i++) {
        addNewVolunteerRow(volunteers[i]);
    }
}


// Function to add a new row for a volunteer
function addNewVolunteerRow(volunteer) {
    // Get the volunteers table body
    var volunteersList = document.querySelector('.volunteers-list');

    // Create a new row
    var newRow = document.createElement('tr');
    newRow.innerHTML = `
        <td contenteditable="true">${volunteer.name}</td>
        <td contenteditable="true">${volunteer.task}</td>
        <td>
        <button class="button" id="dateee" style="border-radius: 10px; background-color: #4b6783; color: white; padding: 5px 10px; border: none; cursor: pointer;">Select Date<input type="date" class="task-deadline" /></button>
        </td>
        <td>
            <button class="edit-button" onclick="addtask(this)">Add Task</button>
        </td>
    `;

    // Append the new row to the volunteers table
    volunteersList.appendChild(newRow);

    // Add event listener for date selection
    newRow.querySelector('#dateee').addEventListener('click', function() {
        // When the button is clicked, focus on the corresponding date input
        newRow.querySelector('.task-deadline').focus();
    });
}
// Function to add a new task for a volunteer
function addtask(button) {
    // Get the current row of the button clicked
    var row = button.parentNode.parentNode;

    // Create a new task row
    var taskRow = document.createElement('tr');
    taskRow.innerHTML = `
        <td contenteditable="true"></td>
        <td contenteditable="true">New Task</td>
        <td><button class="button" id="dateee" style="border-radius: 10px; background-color: #4b6783; color: white; padding: 5px 10px; border: none; cursor: pointer;">Select Date<input type="date" class="task-deadline" /></button></td>
        <td>
            <button class="edit-button" onclick="deleteTask(this)">Delete Task</button>
        </td>
    `;

    // Append the new task row after the current row
    row.parentNode.insertBefore(taskRow, row.nextSibling);

    // Add event listener for date selection
    taskRow.querySelector('#dateee').addEventListener('click', function() {
        // When the button is clicked, focus on the corresponding date input
        taskRow.querySelector('.task-deadline').focus();
    });
}

// Function to delete a task
function deleteTask(button) {
    // Prompt the user for confirmation
    var confirmation = confirm('Are you sure you want to delete this task?');
    if (confirmation) {
        // Remove the task row
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
}

// Function to delete a volunteer
function deleteVolunteer(button) {
    // Prompt the user for confirmation
    var confirmation = confirm('Are you sure you want to delete this volunteer?');
    if (confirmation) {
        // Remove the volunteer row
        var row = button.parentNode.parentNode;
        row.parentNode.removeChild(row);
    }
}
