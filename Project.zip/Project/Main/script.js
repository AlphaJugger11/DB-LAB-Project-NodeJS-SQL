  // Add event listeners to buttons
  document.getElementById('organizer').addEventListener('click', function() {
    window.location.href = 'logino.html';
  });

  document.getElementById('teacher').addEventListener('click', function() {
    window.location.href = 'logint.html';
  });

  document.getElementById('student').addEventListener('click', function() {
    window.location.href = 'logins.html';
  });

  // document.getElementById('volunteer').addEventListener('click', function() {
  //   window.location.href = 'loginv.html';
  // });

  document.getElementById('manager').addEventListener('click', function() {
    window.location.href = 'loginm.html';
  });

  document.getElementById('bckbutt').addEventListener('click', function () {
    window.location.href = 'index.html';
  });

  
  
